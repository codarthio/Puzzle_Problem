public class SearchNode {
}
