public class Board {

    private int size;
    // construct a board from an N-by-N array of blocks
    // (where blocks[i][j] = block in row i, column j)
    public Board(int[][] blocks) {
       size = blocks.length * blocks.length;
    }

    // board size N
    public int size(){
        return size;
    }
    // number of blocks out of place
    public int hamming() {

    }

    public int manhattan() {

    }
    // is this board the goal board?
    public boolean isGoal(){
        return this.hamming() == 0;
    }
    // is this board solvable?
    public boolean isSolvable(){

    }
    // does this board equal y?
    public boolean equals(Object y){

    }
    // all neighboring boards
    public Iterable<Board> neighbors(){

    }
    // string representation of this board (in the output format specified below)
    public String toString() {

    }


    public static void main(String[] args) {

    }
}