public class Solver {
    public Solver(Board initial)           // find a solution to the initial board (using the A* algorithm)
    public int moves()                     // min number of moves to solve initial board
    public Iterable<Board> solution()      // sequence of boards in a shortest solution
    public static void main(String[] args) // solve a slider puzzle (given below)
}